// Load Bootstrap Modal
function loadModal (data, width) {
  var modalId = "myModal";
  if ($("#myModal").length > 0) {
    modalId = "subModal";
  }
  $("body").css("overflow", "hidden");
  switch (width) {
    case 'l' :
      $('<div class="modal fade" id="' + modalId + '" role="dialog">' + data + '</div>').modal()
      .on('shown.bs.modal', function (e) {
        $(this).find('input[type=text],textarea,select').filter(':visible:first').focus();
        //$(".modal-dialog").animate({"width" : "85%"});
        $(".modal-dialog").addClass('modal-lg');
      })
      .on('hidden.bs.modal', function (e) {
        // $(this).data('bs.modal', null);
        $("body").css("overflow", "auto");
        unLoadModal();
      });
    break;

    case 's' :
      $('<div class="modal fade" id="' + modalId + '" role="dialog">' + data + '</div>').modal()
      .on('shown.bs.modal', function (e) {
        $(this).find('input[type=text],textarea,select').filter(':visible:first').focus();
        //$(".modal-dialog").animate({"width" : "40%", "min-width" : "850px"});
        $(".modal-dialog").addClass('modal-sm');
      })
      .on('hidden.bs.modal', function (e) {
        // $(this).data('bs.modal', null);
        $("body").css("overflow", "auto");
        unLoadModal();
      });
    break;

    default :
      $('<div class="modal fade" id="' + modalId + '" role="dialog">' + data + '</div>').modal()
      .on('shown.bs.modal', function (e) {
        $(this).find('input[type=text],textarea,select').filter(':visible:first').focus();
      })
      .on('hidden.bs.modal', function (e) {
        // $(this).data('bs.modal', null);
        $("body").css("overflow", "auto");
        unLoadModal();
      });
    break;
  }
}
// Load Bootstrap Modal
function loadBackModal (data) {
  $("body").css("overflow", "hidden");
  $('<div class="modal fade" id="newModel" role="dialog" style="z-index:1040">' + data + '</div>').modal()
  .on('hidden.bs.modal', function (e) {
    unLoadModal();
  });
}

// Unload Bootstrap Modal
function unLoadModal () {
  if ($("#subModal").length > 0) {
    $("#subModal").modal("hide");
    $("#subModal").remove();
  }
  else {
    $("#myModal").modal("hide");
    $("#myModal").remove();
    $(".modal-backdrop").remove();
    $("body").css("overflow", "auto");
  }
}

// Pre Loader
function preLoader() {
  var pre_loader = "<div id='pre_loader'><div id='preload-text'>Loading...</div></div>";
  $('body').append(pre_loader);
  $('body').css('pointer-events', 'none');
}

// Close Pre Loader
function closePreLoader() {
  $('#pre_loader').remove();
  $('body').css('pointer-events', 'visible');
}
// Loading Icon
var g_loading = "<div class='text-center'><img src='"+WEB_ROOT+"images/ajax-submit.png' /></div>";
var g_position = "<div class='text-center'><img src='"+WEB_ROOT+"images/ajax-loader.gif' /></div>";
var g_big_loading = "<div class='text-center'><img src='"+WEB_ROOT+"images/loading.gif' /></div>";

$(function() {
   // for bind with enter key
  var keyStop = {
   8: ":not(input:text, textarea, input:file, input:password)", // stop backspace = back
   13: "input:text, input:password", // stop enter = submit
   end: null
  };
  $(document).bind("keydown", function(event){
    var selector = keyStop[event.which];
    if(selector !== undefined && $(event.target).is(selector)) {
      $('#search').click();
      event.preventDefault(); //stop event
    }
    return true;
  });
});

$(function(){
  $('#between_dates').prop('checked',false);
});

function change_location(id){
  $.post(WEB_ROOT+"Index/change_Location",{"id":id});
  window.location.reload();
}
/*Floating header*/
function Tablehead() {
  var $table = $('table.fixed-head');
    $table.floatThead({
    responsiveContainer: function($table){
        return $table.closest('.table-responsive');
    }
  });
}

// ########Tree view
$(function() {
  tree();
});
function tree() {
  $('.tree ul > li').show();
  $('.tree ul > li > ul > li').hide();
  applyBasicTree();
};

// Apply Basic Tree
function applyBasicTree() {
  $('.tree li:has(ul)').addClass('parent_li').find(' > span').attr('title', 'Collapse this branch');
  $('.tree li.parent_li > span').on('click', function (e) {
    var children = $(this).parent('li.parent_li').find(' > ul > li');
    if (children.is(":visible")) {
      children.hide('fast');
      $(this).attr('title', 'Expand this branch').find(' > span').addClass('glyphicon-plus-sign').removeClass('glyphicon-minus-sign');
    }
    else {
      children.show('fast');
      $(this).attr('title', 'Collapse this branch').find(' > span').addClass('glyphicon-minus-sign').removeClass('glyphicon-plus-sign');
    }
    e.stopPropagation();
  });
}

// Expand All
function expandAll () {
  $('.tree ul > li').show();
  var children = $(this).parent('li.parent_li').find(' > ul > li');
  children.show('fast');
  $(this).attr('title', 'Collapse').find(' > span').addClass('glyphicon-minus-sign').removeClass('glyphicon-plus-sign');
}

// Collapse All
function collapseAll () {
  $('.tree ul > li').show();
  $('.tree ul > li > ul > li').hide();
  $('.tree ul > li span > span').removeClass('glyphicon-minus-sign');
  $('.tree ul > li span > span').addClass('glyphicon-plus-sign');
}

var loading = '<div class="container-fluid"><div class="row"><div class="col-md-12"><div class="loader"><p>Loading...</p><div class="loader-inner"></div><div class="loader-inner"></div><div class="loader-inner"></div></div></div></div></div>';

var progressbar = '<div class="progress"><div class="progress-bar progress-bar-success progress-bar-striped active" style="width:100%"></div></div>';
var lodinggears = '<i class="fa fa-cog fa-spin fa-3x fa-fw margin-bottom"></i>';
//#####tree view end
// verification status details js
function verification_document_check(){
  var filelength = ($('#document').prop('files').length);
  if(filelength > 3){
    alert('Plese select less then 4 files only');
    return false
  }
}
$(document).ready(function() {
  $('.table-responsive').on('shown.bs.dropdown', function (e) {
    var $table = $(this),
        $menu = $(e.target).find('.dropdown-menu'),
        tableOffsetHeight = $table.offset().top + $table.height(),
        menuOffsetHeight = $menu.offset().top + $menu.outerHeight(true);

    if (menuOffsetHeight > tableOffsetHeight)
      $table.css("padding-bottom", menuOffsetHeight - tableOffsetHeight);
  });

  $('.table-responsive').on('hide.bs.dropdown', function () {
    $(this).css("padding-bottom", 0);
  })
});