<div class="row">
  <div class="col-md-8 col-sm-12 col-xs-12">
    <form name="user_document_form" id="user_document_form" method="post" enctype="multipart/form-data" onsubmit="user_document_insert(event)">
      <input type="hidden" name="id" id="id" value="<?php print $emp['id'];?>">
      <div class="form-group">
        <div class="col-md-12">
          <label>Document type&nbsp;:&nbsp;</label>
          <select name="document_type" id="document_type" class="form-control input-sm">
            <option value="">Select</option>
            <?php foreach ($document_types as $doc_key => $doc_type) {
            $selected = (set_value('document_type') && ($doc_type['id']== set_value('document_type'))) ? "selected='selected'":""; ?>
            <option value="<?php print $doc_type['id'];?>" <?php print $selected;?> ><?php print $doc_type['name'];?></option>
            <?php } ?>
          </select>      
        </div>
      </div>  
      <div class="form-group">
        <label>Documents:&nbsp;</label>
        <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-link" aria-hidden="true">&nbsp;</i></span>
          <div class="col-sm-10">
            <input style="padding: 0px;" class="form-control input-sm doc_limit" name="document_list" id="document_list" type="file">
          </div>
        </div>
      </div>
      <small class="text-danger">Note : Attach pdf, jpg, jpeg, png formats Only. The file should be below 2 MB.</small>
      <div id="employee_documents"></div>
      <div class="">
        <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Submit</button>
        <button type="reset" class="btn btn-sm btn-info"><i class="fa fa-refresh" aria-hidden="true"></i>&nbsp;&nbsp;Reset</button>
      </div>
    </form> 
  </div>
</div>