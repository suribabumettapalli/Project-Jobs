<!DOCTYPE html>
<html>
<head>
	<title>Jobs</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <meta name="robots" content="noindex,nofollow" />
  <meta name="keywords" content=""/>
  <meta name="description" content=""/>
  <!-- Css Files -->
	<link rel="stylesheet" type="text/css" href="<?php print WEB_ROOT; ?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php print WEB_ROOT; ?>assets/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?php print WEB_ROOT; ?>assets/font-awesome/css/font-awesome.min.css"/>
  <link rel="stylesheet" type="text/css" href="<?php print WEB_ROOT;?>assets/css/datepicker.css">
  <!-- Script Files -->
  <script type="text/javascript">var WEB_ROOT = "<?php print WEB_ROOT;?>";</script>
	<script src="<?php print WEB_ROOT; ?>assets/js/jquery.js"></script>
	<script src="<?php print WEB_ROOT; ?>assets/js/bootstrap.js"></script>
	<script src="<?php print WEB_ROOT; ?>assets/js/main.js"></script>
	<script src="<?php print WEB_ROOT; ?>assets/js/user.js"></script>
	<script src="<?php print WEB_ROOT; ?>assets/js/jobs.js"></script>
  <script src="<?php print WEB_ROOT; ?>assets/js/bootstrap-datepicker.js"></script>

</head>
<body>
	<div class="container">
  <?php if(isset($_SESSION['emp'])){ ?>
    <div class="top-menu" style="border-top: 2px solid #0079BD;">
      <nav class="navbar navbar-default">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php print WEB_ROOT;?>Index">
              Jobs
            </a>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="<?php print WEB_ROOT;?>Index"><i class="fa fa-home" aria-hidden="true">&nbsp;</i>Home</a></li>

              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <i class="fa fa-user" aria-hidden="true">&nbsp;</i>
                  <?php $emp = $this->session->userdata('emp'); ?>
                  <?php print $emp['name'];?>
                  <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="<?php print WEB_ROOT;?>User/profile"><i class="fa fa-user" aria-hidden="true">&nbsp;</i>My Profile</a></li>
                  <!-- <li><a href="javascript:profile_edit(<?php print $emp['id']; ?>)"><i class="fa fa-user" aria-hidden="true">&nbsp;</i>Update Profile</a></li> -->
                  <!-- <li><a href="<?php print WEB_ROOT;?>Users"><i class="fa fa-key" aria-hidden="true">&nbsp;</i>Users Administration</a></li> -->
                  <li><a href="<?php print WEB_ROOT;?>User/logout"><i class="fa fa-sign-out"></i>&nbsp;Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  <?php } ?>