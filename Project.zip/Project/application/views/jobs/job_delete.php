<div class="modal-dialog modal-md meghaModal">
  <div class="modal-content">
    <div class="modal-header mgHeader">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title" id="myModalLabel">Delete User</h4>
    </div>
    <form name="user_delete_form" id="user_delete_form" method="post" onsubmit="user_delete_submit(event)">
      <div class="modal-body">
      <input type="hidden" id="id" name="id" value="<?php print $user['id']; ?>" />
      <table class="table">
        <tbody>                    
          <tr>
            <td>Name</td>
            <td>:</td>
            <td><?php if(isset($user['name'])) print $user['name'];?></td>
          </tr>                    
          <tr>
            <td>Mail</td>
            <td>:</td>
            <td class="email"><?php if(isset($user['email'])) print $user['email']; ?></td>
          </tr>
          <tr>
            <td>Mobile</td>
            <td>:</td>
            <td><?php if(isset($user['mobile'])) print $user['mobile']; ?></td>
          </tr>
          <tr>
            <td>Role</td>
            <td>:</td>
            <td>
              <?php if(isset($user['role'])){
                switch ($user['role']){
                  case '1': print "Super Admin";break;
                  case '2': print "Admin";break;
                  case '3': print "User";break;
                  default:'';break;
                }
              } ?>
            </td>
          </tr>
        </tbody>
      </table>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-sm btn-warning"><i class="fa fa-trash" aria-hidden="true">&nbsp;</i>Delete</button>
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-close" aria-hidden="true">&nbsp;</i>Close</button>
      </div>
    </form>
  </div>
</div>