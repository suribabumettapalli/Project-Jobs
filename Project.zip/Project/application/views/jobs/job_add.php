<div class="modal-dialog meghaModal">
  <div class="modal-content">
    <div class="modal-header mgHeader">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title" id="myModalLabel">Job Add</h4>
      </div>
    <form name="jobadd_form" id="jobadd_form" method="post" onsubmit="job_insert(event)">
      <div class="modal-body">
        <?php
          $flash_data = $this->session->flashdata('doc_error');
          if(!empty($flash_data)) {
            $this->load->view('alert',$flash_data);
          }
        ?>

        <div class="form-group">
          <label class="control-label">Company&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="company" name="company" class="form-control input-sm" placeholder="Title" value="<?php print set_value('company');?>" />
          <small class="text-danger"><?php print form_error('company');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Title&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="title" name="title" class="form-control input-sm" placeholder="Title" value="<?php print set_value('title');?>" />
          <small class="text-danger"><?php print form_error('title');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Department&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <select class="form-control input-sm" name="department" id="department">
            <option value="">Select</option>
            <option value="1" <?php if(set_value('department') == 1 ) print "selected='selected'"; ?>>Developent</option>
            <option value="2" <?php if(set_value('department') == 2 ) print "selected='selected'"; ?> >UI-Design</option>
            <option value="3" <?php if(set_value('department') == 3 ) print "selected='selected'"; ?> >Testing</option>
            <option value="4" <?php if(set_value('department') == 4 ) print "selected='selected'"; ?> >Database Analysis</option>
          </select>
          <small class="text-danger"><?php print form_error('department');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Job Description &nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <textarea calss="form-control input-sm" name="job_desc" id="job_desc" rows="2" cols="60"><?php print set_value('job_desc');?></textarea>
          <small class="text-danger"><?php print form_error('job_desc');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Remote&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="remote" id="remote" value="1" <?php if(set_value('remote') == 1 ) print "checked"; ?> >
            <label class="form-check-label" for="1">
              Yes
            </label>
            <span>&nbsp;&nbsp;</span>
            <input class="form-check-input" type="radio" name="remote" id="remote" value="2" <?php if(set_value('remote') == 2 ) print "checked"; ?>>
            <label class="form-check-label" for="2">
              No
            </label>
            <small class="text-danger"><?php print form_error('remote');?></small>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label">Contact No&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="phone" name="phone" class="form-control input-sm" placeholder="Contact No" value="<?php print set_value('phone');?>" />
          <small class="text-danger"><?php print form_error('phone');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Email&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="email" name="email" class="form-control input-sm" placeholder="Email" value="<?php print set_value('email');?>" />
          <small class="text-danger"><?php print form_error('email');?></small>
        </div>
        <div class="form-group">
          <label class="control-label">Address&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <textarea calss="form-control input-sm" name="address" id="address" rows="2" cols="60"><?php print set_value('address');?></textarea>
          <small class="text-danger"><?php print form_error('address');?></small>
        </div>

         <div class="form-group">
          <label class="control-label">PIN code&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="pincode" name="pincode" class="form-control input-sm" placeholder="PIN code" value="<?php print set_value('pincode');?>" />
          <small class="text-danger"><?php print form_error('pincode');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Date Of Expected Join&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <div class="input-group">
            <input type="text" id="doj" name="doj" class="form-control input-sm" placeholder="DD-MM-YYYY" value="<?php print set_value('doj');?>" />
            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
          </div>
          <small class="text-danger"><?php print form_error('doj');?></small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-plus">&nbsp;</i>Add</button>
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-close">&nbsp;</i>Close</button>
      </div>
    </form>
  </div>
</div>

<script type="text/javascript">
  $('#doj').datepicker({format: 'dd-mm-yyyy',startDate: 'today',autoclose: true}).on('changeDate', function(ev) {
    $(this).datepicker('hide');
  });
</script>