<?php
defined('BASEPATH') OR exit('No direct script access allowed');
@include_once('Common.php');
class Index extends Common {
  public function __construct() 
  {
    parent::__construct();
    $this->load->library('session');
    $this->load->model('Common_model');
    $this->load->model('Index_model');
    $this->load->helper(array('security', 'form', 'url'));
  }
  
  /*
  Dashboard
  */
  public function index() 
  {
    $data['emp'] = $this->session->userdata('emp');
    $data['total_jobs'] = $this->Common_model->getAllJobscount();
    $this->load->view('header');
    $this->load->view('index', $data);
    $this->load->view('footer');
  }
}
