<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Common extends CI_Controller {
  public function __construct() 
  {
    parent::__construct();
    setlocale(LC_MONETARY, 'en_IN');
    date_default_timezone_set('Asia/Kolkata');
    $this->load->library('email');
    $this->load->model('Common_model');
    $controller_name = $this->uri->segment(1);
    $function_name = $this->uri->segment(2);
    if (!isset($_SESSION['emp']['id']) and $controller_name != 'Login') {
      redirect(SITE_URL . 'Login', 'refresh');
    }
  }
}