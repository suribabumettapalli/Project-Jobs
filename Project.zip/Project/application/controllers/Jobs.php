<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
@include_once('Common.php');
class Jobs extends Common{
  public function __construct() 
  {
    parent::__construct();
    $this->load->model('Jobs_model');
    $this->load->model('Common_model');
    $this->load->helper('url');
  }

  /*
  Jobs details with pagination
  */
  public function index() 
  {
    $data['params'] = array('rows'=>10, 'pageno' =>1, 'sortby'=>'id', 'sort_order'=>'asc','keywords' => "",);
    $data['params']['tRecords'] = $this->Jobs_model->getJobsNum($data['params']);
    $data['jobs'] = $this->Jobs_model->getJobs($data['params']);
    $this->load->view('header');
    $this->load->view('jobs/jobs',$data);
    $this->load->view("footer");
  }
  
  /*
  Job details with pagination after search results
  */
  public function jobs_body() 
  {
    $data['params'] = $this->input->post();
    $data['params']['tRecords'] = $this->Jobs_model->getJobsNum($data['params']);
    $data['jobs'] = $this->Jobs_model->getJobs($data['params']);
    $this->load->view('jobs/jobs_body',$data);
  }

  /*
  Job add form
  */
  public function job_add() 
  { 
    if($_SESSION['emp']['role'] == 1 || $_SESSION['emp']['role'] == 2) {
      $this->load->view('jobs/job_add');
    }
  }

  /*
  Job insert with validate the required columns
  */
  public function job_insert() 
  {
    if($_SESSION['emp']['role'] == 1 || $_SESSION['emp']['role'] == 2) {
      $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
      $this->form_validation->set_rules('company', 'Company', 'required|trim|max_length[128]');
      $this->form_validation->set_rules('title', 'Title', 'required|trim|max_length[128]');
      $this->form_validation->set_rules('department', 'Department', 'required');
      $this->form_validation->set_rules('job_desc', 'Job Description', 'required');
      $this->form_validation->set_rules('remote', 'Remote', 'required');
      $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required');
      $this->form_validation->set_rules('phone', 'Contact No', 'required|numeric|exact_length[10]|integer|is_natural');
      $this->form_validation->set_rules('address', 'Address', 'required');
      $this->form_validation->set_rules('pincode', 'PIN code', 'required|numeric|exact_length[6]|integer|is_natural');
      $this->form_validation->set_rules('doj', 'Date Of Expected Join', 'required');
      if ($this->form_validation->run() != FALSE) {
        $data = array(
          'title' => $_POST['title'],
          'department' => $_POST['department'],
          'job_desc' => $_POST['job_desc'],
          'address' => $_POST['address'],
          'pincode' => $_POST['pincode'],
          'company' => $_POST['company'],
          'email' => $_POST['email'],
          'phone' => $_POST['phone'],
          'doj' => date('Y-m-d',strtotime($_POST['doj'])),
          'remote' => $_POST['remote'],
          'created_at' => date("Y-m-d H:i:s"), 
          'created_by' => $_SESSION['emp']['id']
        );
        if ($this->Jobs_model->job_insert($data)) {
          $alert = array('color' => 'success', 'msg' => "Job Added Successfully.");
        }
        else {
          $alert = array('color' => 'danger', 'msg' => _("Error Occured.. Please try after some time."));
        }
        $this->load->view("alert_modal", $alert);   
      }
      else {
        $this->load->view("jobs/job_add",$this->input->post());
      }
    }
  }

  /*
  Job edit form
  */
  public function job_edit() 
  {
    if($_SESSION['emp']['role'] == 1) {
      $data['job'] = $this->Jobs_model->getJob($_POST['id']);
      $this->load->view('jobs/job_edit',$data);
    }
  }

  /*
  Job updation with valid columns
  */
  public function job_update() 
  {
    if($_SESSION['emp']['role'] == 1) {
      $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
      $this->form_validation->set_rules('company', 'Company', 'required|trim|max_length[128]');
      $this->form_validation->set_rules('title', 'Title', 'required|trim|max_length[128]');
      $this->form_validation->set_rules('department', 'Department', 'required');
      $this->form_validation->set_rules('job_desc', 'Job Description', 'required');
      $this->form_validation->set_rules('remote', 'Remote', 'required');
      $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required');
      $this->form_validation->set_rules('phone', 'Contact No', 'required|numeric|exact_length[10]|integer|is_natural');
      $this->form_validation->set_rules('address', 'Address', 'required');
      $this->form_validation->set_rules('pincode', 'PIN code', 'required|numeric|exact_length[6]|integer|is_natural');
      $this->form_validation->set_rules('doj', 'Date Of Expected Join', 'required');
      if($this->form_validation->run() != FALSE) {
        $data = array(
          'id' => $_POST['id'],
          'title' => $_POST['title'],
          'department' => $_POST['department'],
          'job_desc' => $_POST['job_desc'],
          'address' => $_POST['address'],
          'pincode' => $_POST['pincode'],
          'company' => $_POST['company'],
          'email' => $_POST['email'],
          'phone' => $_POST['phone'],
          'doj' => date('Y-m-d',strtotime($_POST['doj'])),
          'remote' => $_POST['remote'],
          'updated_at'=>date('Y-m-d H:i:s'),
          'updated_by'=>$_SESSION['emp']['id']
        );
        if($this->Jobs_model->job_update($data)){
          $alert = array('color' => 'success', 'msg' => "Job Updated Successfully.");
          $this->load->view("alert_modal", $alert);
        }
        else {
          $alert = array('color' => 'danger', 'msg' => "Error Occured.. Please try after some time.");
          $this->load->view("alert_modal", $alert);
        }
      }
      else {
        $data['job'] = $this->Jobs_model->getJob($_POST['id']);
        $this->load->view('jobs/job_edit',$data);
      }
    }
  }

  /*
  Job view
  */
  public function job_view() 
  {
    if($_SESSION['emp']['role'] == 1) {
      $data['job'] = $this->Jobs_model->getJob($_POST['id']);
      $this->load->view('jobs/job_view',$data);
    }
  }

  /*
  Job delete form
  */
  public function job_delete() 
  {
    if($_SESSION['emp']['role'] == 1 || $_SESSION['emp']['role'] == 2) {
      $data['job'] = $this->Jobs_model->getJob($_POST['id']);
      $this->load->view('jobs/job_delete',$data);
    }
  }

  /*
  Job Delete(status update)
  */
  public function job_delete_submit() 
  {
    if($_SESSION['emp']['role'] == 1 || $_SESSION['emp']['role'] == 2) {
      $data = array(
        'id' => $_POST['id'],
        'status' => 2,
        'updated_at'=>date('Y-m-d H:i:s'),
        'updated_by'=>$_SESSION['emp']['id'],
      );
      if($this->Jobs_model->job_update($data)){
        $alert = array('color' => 'success', 'msg' => "Job Deleted Successfully.");
        $this->load->view("alert_modal", $alert);
      }
      else {
        $alert = array('color' => 'danger', 'msg' => "Error Occured.. Please try after some time.");
        $this->load->view("alert_modal", $alert);
      }
    }
  }

  /*
  Job status update(Enable/Disable)
  */
  public function job_status() 
  {
    if($_SESSION['emp']['role'] == 1) {
      ($_POST['status'])? $status = 0:$status = 1;
      $data = array('id'=>$_POST['id'],'status'=>$status,'updated_at'=>date('Y-m-d H:i:s'),'updated_by'=>$_SESSION['emp']['id']);
      $this->Jobs_model->job_update($data);
    }
  }
}

