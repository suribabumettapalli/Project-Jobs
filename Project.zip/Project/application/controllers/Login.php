<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {
	public function __construct() {
		parent:: __construct();
    setlocale(LC_MONETARY, 'en_IN');
    date_default_timezone_set('Asia/Kolkata');
    $this->load->model('Index_model');
    $this->load->model('Common_model');
    $this->load->library('session');  
    $this->load->library('email');
    $this->load->helper('security');

  }

  /*
  Login Form
  */
  public function index() 
  {
    if(isset($_SESSION['emp'])){
      redirect(SITE_URL.'Index','refresh');
    }
    if($this->input->post())  {
      $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required|xss_clean');
      $this->form_validation->set_rules('password','Password', 'trim|required|xss_clean|callback_login_submit');
      if(($this->form_validation->run() == FALSE)) {
        $this->load->view("login");
      }
      else {
        redirect(SITE_URL.'Index','refresh');
      }
    }
    else {
      $this->load->view("login");
    }
  }

  /*
  Login submit and crate session
  */
  public function login_submit($password)
  {
    $user_name = $this->input->post('email');
    $result = $this->Index_model->login($user_name, md5($password));
    if($result) {
      $roles = explode(",", trim($result['role'], ','));
      $sess_array = array(
        "id" => $result['id'],
        "email" => $result['email'],
        "name" => $result['name'],
        "role" => $result['role'],
        "mobile" => $result['mobile'],
      );
      unset($result['password']);
      $this->session->set_userdata('emp', $sess_array);
      return TRUE;
    }
    else {
      $this->form_validation->set_message('login_submit', _('Invalid username or password'));
      return false;
    }
  }
}