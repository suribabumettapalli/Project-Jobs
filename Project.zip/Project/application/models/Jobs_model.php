<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Jobs_model extends CI_Model {
  public function __construct() 
  {
    $this->load->database();
  }

  /*
  Get jobs reports count
  */
  public function getJobsNum($params)
  {
    $this->db->select('count(*) as tRecords');
    $this->db->from('jobs');
    $this->db->where('status !=',2);
    if(isset($params['s_department'])&& !empty($params['s_department'])){
      $this->db->where('department',$params['s_department']);
    }
    if (isset($params['keywords']) and $params['keywords'] !='') {
      $this->db->group_start();
      $this->db->like("title", $params['keywords']);
      $this->db->or_like("company", $params['keywords']);
      $this->db->or_like("job_desc", $params['keywords']);
      $this->db->or_like("phone", $params['keywords']);
      $this->db->or_like("email", $params['keywords']);
      $this->db->group_end();
    }
    $qry = $this->db->get();
    if ($qry->num_rows() > 0) {
      $result = $qry->result_array();
      return $result[0]['tRecords'];
    }
    return false;
  }

  /*
  Get jobs reports
  */
  public function getJobs($params)
  {
    $this->db->select('*');
    $this->db->where('status !=',2);
    if(isset($params['s_department'])&& !empty($params['s_department'])){
      $this->db->where('department',$params['s_department']);
    }
    if (isset($params['keywords']) and $params['keywords'] !='') {
      $this->db->group_start();
      $this->db->like("title", $params['keywords']);
      $this->db->or_like("company", $params['keywords']);
      $this->db->or_like("job_desc", $params['keywords']);
      $this->db->or_like("phone", $params['keywords']);
      $this->db->or_like("email", $params['keywords']);
      $this->db->group_end();
    }
    $this->db->order_by($params['sortby'], $params['sort_order']);
    $qry = $this->db->get('jobs', $params['rows'], ($params['pageno']-1)*$params['rows']);
    if($qry->num_rows()>0) {
      foreach($qry->result_array() as $key => $jobs) {
        $jobss[$jobs['id']] = $jobs;
      }
      return $jobss;
    }
    return false;
  }

  /*
  Get jobs details
  */
  public function getJob($id)
  {
    $qry = $this->db->select('*')->where('id',$id)->get('jobs');
    if($qry->num_rows()>0) {
      $jobs = $qry->result_array();
      return $jobs[0];
    }
    return false;
  }

  /*
  JOb insertion
  */
  public function job_insert($data)
  {
    $insert = $this->db->insert('jobs', $data);
    if($insert){
      return true;
    }
    return false;
  }

  /*
  Job Updation
  */
  public function job_update($data)
  {
    return $this->db->where('id', $data['id'])->update('jobs', $data);
  }
  
  /*
  job delete
  */
  public function job_delete($id)
  {
    return $this->db->where('id',$id)->delete('jobs');
  }
}