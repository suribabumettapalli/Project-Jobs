<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_Model extends CI_Model {
  public function __construct() 
  {
    $this->load->database();
  }

  /*
  Get all user reports.
  */
  public function getUserdata($id)  
  {
    $this->db->select("*");
    $this->db->where("id",$id);
    $this->db->from("users");
    $qry = $this->db->get();
    return $qry->row_array();
  }

  /*
  User data update.
  */
  public function user_update($data,$id)
  {
    $this->db->set($data);
    $this->db->where('id',$id);
    return $this->db->update('users',$data);
  }

  /*
  Password checking
  */
  public function check_password($id, $password)
  {
    $query = $this->db->where('id', $id)->where('password', $password)->where('status', 1)->get('employee');
    if ($query->num_rows() == 1) {
      $result = $query->row_array();
      return $result;
    }
    return false;
  }

  /*
  Password update.
  */
  public function update_password($data)
  {
    return $this->db->where('id',$data['id'])->update('employee',array('password'=>$data['password']));
  }

  /*
  Get user documents
  */
  public function getUserDocuments($id)
  {
    $qry = $this->db->select('*')->from('documents')->where('user_id',$id)->where('status',1)->get();
    if($qry->num_rows() > 0){
      return $qry->result_array();
    }
    return array();
  }

  /*
  Document insert
  */
  public function user_document_insert($data)
  {
    $insert = $this->db->insert('documents',$data);
    if($insert){
      $this->db->insert_id();
    }else{
      return false;
    }
  }

  /*
  Document delete
  */
  public function user_document_delete($id)
  {
    $qry=$this->db->set('status',0)->where('id',$id)->update('documents');
    if($qry){
      return true;
    }else{
      return false;
    }
  }
}